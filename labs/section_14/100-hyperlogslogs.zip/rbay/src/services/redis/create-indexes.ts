export const createIndexes = async () => {};
